const donasi = () => {
	return `

┏━━━━━━━━━━━━━━━━━━━━
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ Donasi Seikhlasnya❉⊰━━✿
┃  
┣━⊱ *DANA*
┣⊱ 08Soon
┣━⊱ *PULSA*
┣⊱ 0858-0944-0506
┃
┣━━━━━━━━━━━━━━━━━━━━
┃  *BOT BY JDR*
┗━━━━━━━━━━━━━━━━━━━━

`
}

exports.donasi = donasi
